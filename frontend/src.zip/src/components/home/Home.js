import Hero from '../hero/Hero';

const Home = ({ movies }) => {
  return (
    <div>
      {movies?.map((movie) => (
        <Hero key={movie.id} movie={movie} />
      ))}
    </div>
  );
};

export default Home;
